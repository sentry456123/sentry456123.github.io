from subprocess import Popen
import time


while True:
    Popen("AMOGUSVIRUS.exe")
    time.sleep(2)
